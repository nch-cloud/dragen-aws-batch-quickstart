#!/usr/bin/env python
# Copyright 2018 Illumina, Inc. All rights reserved.
#
# This file contains confidential and proprietary information of the Edico Genome
# Corporation and is protected under the U.S. and international copyright and other
# intellectual property laws.
#
# $Id$
# $Author$
# $Change$
# $DateTime$
#
# Wrapper to start processes in the background and catch any signals used to
# terminate the process.  Multiple processes are executed sequentially.  Stops dragen
# processes gracefully by running dragen_reset when dragen_board is in use.
#

from __future__ import print_function

from builtins import filter
from builtins import str
from builtins import object
import copy
import datetime
import glob
import os
import resource
import shutil
import subprocess
import sys
import time
import uuid
import six
import re
import tarfile

#########################################################################################
# printf - Print to stdout with flush
#
def printf(msg):
    print(msg, file=sys.stdout)
    sys.stdout.flush()


#########################################################################################
# get_s3_bucket_key - Extract S3 bucket and key from input URL if it is S3 bucket
#   Input s3_url expected format s3://bucket/key
#   Return a tuple: (s3_found, bucket, key), i.e. (False, None, None) if not found
#
def get_s3_bucket_key(s3_url):
    try:
        s3_url = s3_url.strip()
        if s3_url.find('s3://') != 0:
            raise Exception('Not S3 URL - could not get bucket and key')
        # Extract the bucket and key
        s3_path = s3_url.replace('//', '/')
        s3_bucket = s3_path.split('/')[1]
        s3_key = '/'.join(s3_path.split('/')[2:])
        return True, s3_bucket, s3_key
    # Confirm S3 URL
    except Exception as e:
        return False, None,  None


#########################################################################################
# find_arg_in_list - Interate through a list of arguments and find the first occurrence
# of any of the arguments listed as argv
#
def find_arg_in_list(arglist, *argv):
    index = -1
    for arg in argv:
        try:
            index = arglist.index(arg)
            break
        except ValueError:
            continue
    return index


#########################################################################################
# exec_cmd - Execute command and return [stdout/stderr, exitstatus]
#
def exec_cmd(cmd):
    printf("Executing %s" % cmd.strip())
    p = subprocess.Popen(cmd.split())
    err = p.wait()
    return err

def exec_cmd(cmd, logfile=None):
        printf("Executing %s" % cmd.strip())
        p = subprocess.Popen(cmd.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        output = ""
        for line in p.stdout:
                line = line.decode('utf-8')
                print(line.strip())
                output += line

        err = p.wait()

        if logfile:
                print(logfile)
                with open(logfile , 'w') as f:
                        f.write(output)
        return err


#########################################################################################
# address CVE-2007-4559
#

def is_within_directory(directory, target):
    abs_directory = os.path.abspath(directory)
    abs_target = os.path.abspath(target)
    return os.path.commonpath([abs_directory]) == os.path.commonpath([abs_directory, abs_target])

def safe_extract(tar, path=".", members=None):
    for member in tar.getmembers():
        member_path = os.path.join(path, member.name)
        if not is_within_directory(path, member_path):
            raise Exception(f"Unsafe path detected: {member.name}")
    tar.extractall(path, members)


#########################################################################################
# DragenJob - Dragen Job execution object
#
class DragenJob(object):
    DRAGEN_PATH = '/opt/edico/bin/dragen'
    D_HAUL_UTIL = 'python3 /root/quickstart/d_haul'
#    D_HAUL_UTIL = 'python3 /home/hjo/test/AWS_refactor/d_haul'
    DRAGEN_LOG_FILE_NAME = 'dragen_log_%d.txt'
    DEFAULT_DATA_FOLDER = '/home/hjo/test/AWS_refactor/'
    DEFAULT_DATA_FOLDER = '/ephemeral/'
    CLOUD_SPILL_FOLDER = '/ephemeral/'

    FPGA_DOWNLOAD_STATUS_FILE = DEFAULT_DATA_FOLDER + 'fpga_dl_stat.txt'
    REDIRECT_OUTPUT_CMD_SUFFIX = '> %s 2>&1'

    ########################################################################################
    #
    def __init__(self, dragen_args):

        self.orig_args = dragen_args
        self.new_args = copy.copy(dragen_args)

        # Inputs needed for downloading
        self.ref_dir = None             # Create local directory to download reference
        self.input_dir = None           # Create local directory for Dragen input info

        self.ref_s3_uri = None
        self.ref_s3_uri_index = -1

        self.local_bcl_path = None      # Create local directory for bcl-convert-only

        self.output_s3_url = None       # Determine from the --output-directory field
        self.output_s3_index = -1
        self.output_dir = None          # Create local output directory for current dragen process

        # Run-time variables
        self.input_dir = None          # Create local output directory for current dragen process
        self.process_start_time = None  # Process start time
        self.process_end_time = None    # Process end time
        self.global_exit_code = 0       # Global exit code. If any process fails then we exit with a non-zero status

        self.exclusion = [ '--ref-dir', '-r', '--output-directory', '--lic-server' ]
        self.cloud_files = []

        self.set_resource_limits()

    ########################################################################################
    # set_resource_limits - Set resource limits prior.
    #
    def set_resource_limits(self):
        # Set resource limits based on values in /etc/security.d/limits.d/99-edico.conf
        edico_limits = "/etc/security/limits.d/99-edico.conf"
        rlimit = {}
        if os.path.exists(edico_limits):
            limitsfd = open(edico_limits, 'r')
            for line in limitsfd:
                fields = line.split()
                if fields[0] == '*' and fields[2] in ['nproc', 'nofile', 'stack']:
                    res = eval("resource.RLIMIT_%s" % fields[2].upper())
                    if fields[3] == "unlimited":
                        rlimit[res] = resource.RLIM_INFINITY
                    else:
                        if fields[2] == 'stack':
                            # limits.conf file is in KB, setrlimit command takes bytes
                            rlimit[res] = int(fields[3]) * 1024
                        else:
                            rlimit[res] = int(fields[3])
        else:
            rlimit[resource.RLIMIT_NPROC] = 16384
            rlimit[resource.RLIMIT_NOFILE] = 65535
            rlimit[resource.RLIMIT_STACK] = 10240 * 1024

        for res, limit in six.iteritems(rlimit):
            printf("Setting resource %s to %s" % (res, limit))
            try:
                resource.setrlimit(res, (limit, limit))
            except Exception as e:
                msg = "Could not set resource ID %s to hard/soft limit %s (error=%s)" \
                      % (res, limit, e)
                printf(msg)
        return

    ########################################################################################
    # copy_var_log_dragen_files - Copy over the most recent /var/log/dragen files to output dir
    # Look for the latest below type of files:
    # /var/log/dragen_run_<timestamp>_<pid>.log
    # /var/log/hang_diag_<timestamp>_<pid>.txt
    # /var/log/pstack_<timestamp>_<pid>.log
    # /var/log/dragen_info_<timestamp>_pid.log
    # /var/log/dragen_replay_<timestamp>_pid.json
    #
    def copy_var_log_dragen_files(self):
        files = list(filter(os.path.isfile, glob.glob("/var/log/dragen/dragen_run*")))
        if files:
            newest_run_file = sorted(files, key=lambda x: os.path.getmtime(x), reverse=True)[0]
            shutil.copy2(newest_run_file, self.output_dir)

        files = list(filter(os.path.isfile, glob.glob("/var/log/dragen/hang_diag*")))
        if files:
            newest_hang_file = sorted(files, key=lambda x: os.path.getmtime(x), reverse=True)[0]
            shutil.copy2(newest_hang_file, self.output_dir)

        files = list(filter(os.path.isfile, glob.glob("/var/log/dragen/pstack*")))
        if files:
            newest_pstack_file = sorted(files, key=lambda x: os.path.getmtime(x), reverse=True)[0]
            shutil.copy2(newest_pstack_file, self.output_dir)

        files = list(filter(os.path.isfile, glob.glob("/var/log/dragen/dragen_info*")))
        if files:
            newest_info_file = sorted(files, key=lambda x: os.path.getmtime(x), reverse=True)[0]
            shutil.copy2(newest_info_file, self.output_dir)

        files = list(filter(os.path.isfile, glob.glob("/var/log/dragen/dragen_replay*")))
        if files:
            newest_replay_file = sorted(files, key=lambda x: os.path.getmtime(x), reverse=True)[0]
            shutil.copy2(newest_replay_file, self.output_dir)

        return

    ########################################################################################
    # download_dragen_fpga - Perform the 'partial reconfig' to download binary image to FPGA
    #   NOTE: Should ONLY be called when self.FPGA_DOWNLOAD_STATUS_FILE does not exist
    #
    def download_dragen_fpga(self):
        exit_code = \
            exec_cmd("/opt/edico/bin/dragen --partial-reconfig DNA-MAPPER --ignore-version-check true -Z 0")
        if not exit_code:
            # PR complete success. Write '1' into status file
            f = open(self.FPGA_DOWNLOAD_STATUS_FILE, 'w')
            f.write('1')
            f.close()
            printf('Completed Partial Reconfig for FPGA')
            return True

        # Error!
        printf('Could not do initial Partial Reconfig program for FPGA')
        return False

    ########################################################################################
    # check_board_state - Check dragen_board state and run reset (if needed)
    #
    def check_board_state(self):
        exit_code = exec_cmd("/opt/edico/bin/dragen_reset -cv")
        if not exit_code:
            return

        printf("Dragen board is in a bad state - running dragen_reset")
        exec_cmd("/opt/edico/bin/dragen_reset")
        return

    ########################################################################################
    # exec_download - Download a file from the given URL to the target directory
    #
    def exec_url_download(self, url, target_dir):
        dl_cmd = '{bin} --mode download --url {url} --path {target} -s'.format(
            bin=self.D_HAUL_UTIL,
            url=url,
            target=target_dir)

        exit_code = exec_cmd(dl_cmd)

        if exit_code:
            printf('Error: Failure downloading from S3. Exiting with code %d' % exit_code)
            sys.exit(exit_code)
        return

    ########################################################################################
    # download_s3_object: Download an object from S3 bucket/key to spefific target file path
    #
    def download_s3_object(self, bucket, key, target_path):
        dl_cmd = '{bin} --mode download --bucket {bucket} --key {key} --path {target} -s'.format(
            bin=self.D_HAUL_UTIL,
            bucket=bucket,
            key=key,
            target=target_path)
        exit_code = exec_cmd(dl_cmd)

        if exit_code:
            printf('Error: Failure downloading from S3. Exiting with code %d' % exit_code)
            sys.exit(exit_code)


    def parse_input_args(self):
        if not self.input_dir:
            self.input_dir = self.DEFAULT_DATA_FOLDER + 'inputs/'
        printf(f'[DEBUG] Processing arguments: {self.orig_args}')
        for i, arg in enumerate(self.orig_args):
            prev_arg = self.orig_args[i - 1] if i > 0 else None

            if prev_arg == '--bcl-input-directory':
                    s3_parts = arg.replace('s3://', '').split('/')
                    s3_key_base = '/'.join(s3_parts[1:])
                    # Handle if directory is a tar
                    if s3_key_base.endswith('.tar'):
                        # Handle tar file creating its own directory structure
                        filename = s3_key_base.split('/')[-1].split('.tar')[0]
                        self.local_bcl_path = self.input_dir + filename
                    else:
                        s3_key = s3_key_base.rstrip('/')
                        # Store local path for BCL directory
                        self.local_bcl_path = self.input_dir + s3_key 
                    print(f'Using the following path {self.local_bcl_path}')


            if prev_arg in self.exclusion:
                if prev_arg == '--ref-dir':
                    self.ref_s3_uri_index = i - 1
                    self.ref_s3_uri = arg
                elif prev_arg == '--output-directory':
                    self.output_directory_s3_uri_index = i - 1
                    self.output_directory_s3_uri = arg

                continue

            if arg.startswith("s3://") or arg.startswith("https://"):
                filename = arg.split('?')[0].split('/')[-1]  # Extract filename
                target_path = self.input_dir + filename  # Local path
                self.cloud_files.append(arg)

                self.new_args[i] = target_path  # Update argument list



    ########################################################################################
    # download_inputs: Download specific Dragen inputs needed from provided URLs, and
    # replace them with a local path, i.e. fastq_list, bed files, etc.
    #
    def download_inputs(self):

        if not self.input_dir:
            self.input_dir = self.DEFAULT_DATA_FOLDER + 'inputs/'
        
        
        for cloud_file in self.cloud_files:
            filename = cloud_file.split('?')[0].split('/')[-1]
            is_tar_file = re.search(r'\.tar(\.gz)?$', filename)
            s3_valid, s3_bucket, s3_key = get_s3_bucket_key(cloud_file)
            target_path = self.input_dir + str(filename)
            print(f'downloading {target_path}')
            
            if s3_valid:
                self.download_s3_object(s3_bucket, s3_key, target_path)
                # Download .crai index for .cram files
                if filename.endswith('.cram'):
                    self.download_s3_object(s3_bucket, s3_key + '.crai', target_path + '.crai')
            else:
                # Try to download using http
                self.exec_url_download(cloud_file, self.input_dir)
                if filename.endswith('.cram'):
                    self.exec_url_download(cloud_file + '.crai', self.input_dir)
            if is_tar_file:
                tar_extract_dir = self.input_dir

                # Ensure it exists
                if not os.path.exists(target_path):
                    raise FileNotFoundError(f'Downloaded file not found: {target_path}')
    
                # Extract
                try:
                    with tarfile.open(target_path, mode="r:*") as tar:
                        print('Extracting tarball...')
                        safe_extract(tar, path=tar_extract_dir)
                    print(f'Successfully extracted to {tar_extract_dir}')
                except Exception as e:
                    raise RuntimeError(f'Error extracting tar file: {e}')
        return

    ########################################################################################
    # download_ref_tables: Download directory of reference hash tables using the S3
    #  "directory" prefix self.ref_s3_url should be in format s3://bucket/ref_objects_prefix
    #

    def download_ref_tables(self):
        if not self.ref_s3_uri:
            print('Warning: No reference HT directory URL specified!')
            return

    # Parse S3 URI
        s3_valid, s3_bucket, s3_key = get_s3_bucket_key(self.ref_s3_uri)
        if not s3_valid or not s3_key or not s3_bucket:
            raise ValueError(f'Could not parse S3 bucket/key from: {self.ref_s3_uri}')

        is_tar_file = re.search(r'\.tar(\.gz)?$', s3_key)
        target_path = self.DEFAULT_DATA_FOLDER

        if is_tar_file:
            # Handle tarball case
            ref_tar_filename = os.path.basename(s3_key)
            ref_tar_path = os.path.join(target_path, ref_tar_filename)
            ref_dirname = re.sub(r'\.tar(\.gz)?$', '', ref_tar_filename)
            ref_dir = os.path.join(target_path, ref_dirname)

            # Download .tar file
            try:
                self.download_s3_object(s3_bucket, s3_key, ref_tar_path)
            except Exception as e:
                raise RuntimeError(f'Failed to download tar file from S3: {e}')

            # Ensure it exists
            if not os.path.exists(ref_tar_path):
                raise FileNotFoundError(f'Downloaded file not found: {ref_tar_path}')

            # Extract
            try:
                os.makedirs(ref_dir, exist_ok=True)
                with tarfile.open(ref_tar_path, mode="r:*") as tar:
                    print('Extracting reference tarball...')
                    safe_extract(tar, path=ref_dir)
                print(f'Successfully extracted to {ref_dir}')
            except Exception as e:
                raise RuntimeError(f'Error extracting tar file: {e}')


            self.ref_dir = ref_dir

        else:
            # Handle folder (prefix) case
            try:
                self.download_s3_object(s3_bucket, s3_key, target_path)
            except Exception as e:
                raise RuntimeError(f'Failed to download reference folder from S3: {e}')

            # Construct local directory path
            ref_dir = os.path.join(target_path, s3_key)
            if not os.path.exists(ref_dir):
                raise FileNotFoundError(f'Expected reference folder not found after download: {ref_dir}')

            self.ref_dir = ref_dir

        # Update argument list
        self.new_args[self.ref_s3_uri_index + 1] = self.ref_dir


    ########################################################################################
    # Upload the results of the job to the desired bucket location
    #    output_s3_url should be in format s3://bucket/output_objects_prefix
    # Returns:
    #    Nothing if success
    def upload_job_outputs(self):
        if not self.output_directory_s3_uri:
            printf('Error: Output S3 location not specified!')
            return

        # Generate the command to upload the results
        s3_valid, s3_bucket, s3_key = get_s3_bucket_key(self.output_directory_s3_uri)

        if not s3_valid or not s3_key or not s3_bucket:
            printf('Error: could not get S3 bucket and key info from specified URL %s' % self.output_directory_s3_uri)
            sys.exit(1)

        ul_cmd = '{bin} --mode upload --bucket {bucket} --key {key} --path {file} -s'.format(
            bin=self.D_HAUL_UTIL,
            bucket=s3_bucket,
            key=s3_key,
            file=self.output_dir.rstrip('/'))

        exit_code = exec_cmd(ul_cmd)

        if exit_code:
            printf('Error: Failure uploading outputs. Exiting with code %d' % exit_code)
            sys.exit(exit_code)

        return

    ########################################################################################
    # create_output_dir - Checks for existance of outdir and creates it if necessary,
    # and saves it to internal self.output_dir variable
    #
    def create_output_dir(self):
        if not self.output_dir or not os.path.exists(self.output_dir):
            self.output_dir = self.DEFAULT_DATA_FOLDER + str(uuid.uuid4())
            printf("Output directory does not exist - creating %s" % self.output_dir)
            try:
                os.makedirs(self.output_dir)
            except os.error:
                # dragen execution will fail
                printf("Error: Could not create output_directory %s" % self.output_dir)
                sys.exit(1)
        else:
            printf("Output directory %s already exists - Skip creating." % self.output_dir)

        # Add or replace the output directory in the dragen parameters
        self.new_args[self.output_directory_s3_uri_index + 1] = self.output_dir

        return

    ########################################################################################
    # run_job - Create the command line for the given process, launch it, and monitor
    # it for completion.
    #
    def run_job(self):

        # Check if FPGA image download is needed
        if not os.path.isfile(self.FPGA_DOWNLOAD_STATUS_FILE):
            self.download_dragen_fpga()


        # If board is in bad state, run dragen_reset before next process starts
        self.check_board_state()
        
        # If BCL convert, set the correct path for where BCL folder is downloaded
        for i, arg in enumerate(self.new_args):
            if i > 0 and self.new_args[i-1] == '--bcl-input-directory':
                self.new_args[i] = self.local_bcl_path
                self.DEFAULT_DATA_FOLDER += 'bclconvertonly/'
                break
        # Setup unique output directory
        self.create_output_dir()
        # Add some internally defined parameters
        self.new_args.extend(
            ['--intermediate-results-dir', self.CLOUD_SPILL_FOLDER]
        )
        self.new_args.extend(
            ['--lic-no-print']
        )
        # expand the Dragen args to construct the full command
        dragen_opts = ' '.join(self.new_args)
        # Construct the 'main' Dragen command
        dragen_cmd = "%s %s " % (self.DRAGEN_PATH, dragen_opts)
        # Save the Dragen output to a file instead of stdout
        log_filename = self.DRAGEN_LOG_FILE_NAME % round(time.time())
        output_log_path = os.path.join(self.output_dir, log_filename)

        # Run the Dragen process
        self.process_start_time = datetime.datetime.now(datetime.UTC)
        exit_code = exec_cmd(dragen_cmd, output_log_path)
        # Upload the results to S3 output bucket
        self.upload_job_outputs()

        # Delete the output results directory, i.e. /staging/<uuid4>
        # NOTE: Do not delete the reference directory enable re-use with another job
        rm_out_path = self.output_dir
        printf("Removing Output dir %s" % rm_out_path)
        shutil.rmtree(rm_out_path, ignore_errors=True)

        # Handle error code
        if exit_code:
            self.copy_var_log_dragen_files()
            self.global_exit_code = exit_code
            if self.global_exit_code > 128 or self.global_exit_code < 0:
                if self.global_exit_code > 128:
                    signum = self.global_exit_code - 128
                else:
                    signum = -self.global_exit_code
                printf("Job terminated due to signal %s" % signum)

        self.process_end_time = datetime.datetime.now(datetime.UTC)
        return

    ########################################################################################
    # run - Run all processes in the job.
    #
    def run(self):
        try:
            self.run_job()
            printf("Job is exiting with code %s" % self.global_exit_code)
            sys.exit(self.global_exit_code)

        except SystemExit as inst:
            if inst != 0:  # System exit with exit code 0 is OK
                printf("Caught SystemExit: Exiting with status %s" % inst)
                sys.exit(inst)
            else:
                printf("Caught SystemExit: Exiting normally")

        except:
            # Log abnormal exists
            printf("Unhandled exception in dragen_qs: %s" % sys.exc_info()[0])
            sys.exit(1)

        delta = self.process_end_time - self.process_start_time
        printf("Job ran for %02d:%02d:%02d" % (delta.seconds//3600, delta.seconds//60 % 60, delta.seconds % 60))
        sys.exit(0)


#########################################################################################
# main
#
def main():
    # import ipdb; ipdb.set_trace()
    # Configure command line arguments
    dragen_args = sys.argv[1:]

    # Debug print (remove later)
    printf("[DEBUG] Dragen input commands: %s" % ' '.join(dragen_args))

    dragen_job = DragenJob(dragen_args)

    dragen_job.parse_input_args()


    printf('Downloading reference files')
    dragen_job.download_ref_tables()

    printf('Downloading misc inputs (csv, bed)')
    dragen_job.download_inputs()

    printf('Run Analysis job')
    dragen_job.run()


if __name__ == "__main__":
    main()
